package Lab5;

import static org.junit.Assert.*;

import org.junit.Test;

public class ControlerTest {

	@Test
	public void test() {
		fail("Not yet implemented");
	}

}
